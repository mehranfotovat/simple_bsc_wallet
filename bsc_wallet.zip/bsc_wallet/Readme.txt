requirements:django,django rest framework, web3
project detail:a bsc wallet with restful api

in order to run the project first you need to install the requirement packages listed above.
inside wallet_api/views.py ive documented how you can interact with the project

developed by: @mehran fotovat
