from django.http import HttpResponse
from django.shortcuts import redirect
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Address
from .serializers import AddressSerializer
from web3 import Web3


#BSC Test Network Connection
w3 = Web3(Web3.HTTPProvider('https://data-seed-prebsc-1-s1.binance.org:8545/'))
#If you want to connect to the BSC Main network just change the link above with main network address



@api_view(['GET'])
def apiOverView(request):
    api_urls = {
        'List': 'addresses-list',
        'Create': 'addresses-create',
        # create url: http://127.0.0.1:8000/addresses-create/
        # Create Example: {"name": "myAccount"}
        'Detail': 'address-detail/<str:pk>pk=address',
        # Detail url: http://127.0.0.1:8000/address-detail/0x19Bd3593b61205390183f9E5a0D0DD69C0E55bCa
        'Send': 'address-send/<str:pk>pk=address',
        # Send url: http://127.0.0.1:8000/address-send/0xe489C9D8Cd907dCd9252254c7a194d5Ec0dDb249 The last part is address of the account you want send bsc with
        # Send Example: {"amount":0.2,"reciever_address":"0xe489C9D8Cd907dCd9252254c7a194d5Ec0dDb249"}
    }
    return Response(api_urls)

'''@dev to get account lists /addresses-list/'''
@api_view(['GET'])
def listAddresses(request):
    addresses = Address.objects.all()
    serializer = AddressSerializer(addresses, many=True)
    print(addresses)
    return Response(serializer.data)

'''@dev in order to create an account you need to go to /addresses-create and 
your api needs a value "name" to create account'''
@api_view(['POST'])
def createAddress(request):
    account = w3.eth.account.create()
    name = request.data.get('name')
    if name is not None:
        account_address = Address.objects.create(name=name, address=account.address, private_key=w3.toHex(account.key))
        account_detail = {
            'name':account_address.name,
            'address':account_address.address,
            'private_key':account_address.private_key
        }
        return Response(account_detail)
    else:
        return Response({"Error": "Bad request"})


#if you dont want to send the private_key you can remove it from account detail
@api_view(['GET'])
def detailAddress(request, pk):
    try:
        account = Address.objects.get(address=pk)
        serializer = AddressSerializer(account, many=False)
        account_detail = {
            'name':account.name,
            'address':account.address,
            'bsc_balance':w3.fromWei(w3.eth.get_balance(serializer.data['address']), 'ether'),
            'private_key':account.private_key,
        }
        return Response(account_detail)
    except:
        return Response({"Error": "Account Does not exist"})


'''@dev in order to send transaction you need to go to /address-send/{your address} after that
your post request needs two values 'amount' in ETHER and 'reciever_address'
'''
@api_view(['POST'])
def sendFromAddress(request, pk):
    try:
        account = Address.objects.get(address=pk)
        serializer = AddressSerializer(account, many=False)
        amount = request.data.get('amount')
        reciever_address = request.data.get('reciever_address')

        nonce = w3.eth.get_transaction_count(serializer.data['address'])

        tx = {
            'nonce':nonce,
            'to':reciever_address,
            'value': w3.toWei(amount, 'ether'),
            'gas': 2000000,
            'gasPrice': w3.toWei('50', 'gwei'),
        }
        signed_tx = w3.eth.account.sign_transaction(tx, account.private_key)
        tx_hash = w3.eth.send_raw_transaction(signed_tx.rawTransaction)

        transaction_detail = {
            'from':serializer.data['address'],
            'to':reciever_address,
            'amount':amount,
            'tx_hash':w3.toHex(tx_hash),
        }
        return Response(transaction_detail)
    except ValueError:
        return Response({"Error": "Bad request not enough bsc"})
        
    except:
        return Response({"Error": "Bad request"})