from rest_framework import serializers
from .models import Address

# this way you wont show the private key in list addresses api
# if you dont want to show private key uncomment this serializer class and comment the other AddressSerializer
# class AddressSerializer(serializers.HyperlinkedModelSerializer):
#     class Meta:
#         model = Address
#         fields = ['name', 'address']


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['name', 'address']
        fields = '__all__'
