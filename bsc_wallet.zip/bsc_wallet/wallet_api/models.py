from django.db import models


class Address(models.Model):
    name = models.CharField(max_length=200)
    address = models.CharField(max_length=400)
    private_key = models.CharField(max_length=600)

    def __str__(self):
        return self.name