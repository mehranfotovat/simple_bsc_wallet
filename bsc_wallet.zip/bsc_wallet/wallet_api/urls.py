from django.urls import path
from .views import apiOverView, createAddress, detailAddress, listAddresses, sendFromAddress


urlpatterns = [
    path('', apiOverView),
    path('addresses-list/', listAddresses),
    path('addresses-create/', createAddress),
    path('address-detail/<str:pk>', detailAddress),
    path('address-send/<str:pk>', sendFromAddress),
]
